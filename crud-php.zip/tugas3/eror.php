<?php
echo "Terjadi Kesalahan";
?>